for(var i = 0; i < 5; i = i + 1){
runLoop(i)
}

function runLoop(number){
  console.log("This loop has run " + number + " times");
}
